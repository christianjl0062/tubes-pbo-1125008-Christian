package marvel.christian.tubes.pbo.config;

// ini diambil dari template yang dikasih dari tugas PPBO database minggu 8.
public class AppConfig {
    public static final String DATABASE = "tubespbo";
    public static final String PORT = "5432";
    public static final String HOST = "localhost";
    public static final String USER = "postgres";
    public static final String PASSWORD = "!thb2025";
}
